// Kelas abstrak Animal
class Animal {
    constructor(nama, habitat) {
        if (this.constructor === Animal) {
            throw new Error("Tidak bisa membuat objek langsung dari kelas abstrak Animal.");
        }
        this.nama = nama;
        this.habitat = habitat;
    }

    // Metode abstrak
    bersuara() {
        throw new Error("Metode abstrak bersuara() harus diimplementasikan.");
    }
}

// Kelas bantuan untuk jenis habitat
class Darat extends Animal {
    constructor(nama) {
        super(nama, "Darat");
    }

    bergerak() {
        console.log(`${this.nama} sedang bergerak di darat.`);
    }
}

class Air extends Animal {
    constructor(nama) {
        super(nama, "Air");
    }

    berenang() {
        console.log(`${this.nama} sedang berenang di air.`);
    }
}

class Amfibi extends Animal {
    constructor(nama) {
        super(nama, "Amfibi");
    }

    bergerak() {
        console.log(`${this.nama} bisa bergerak di darat dan di air.`);
    }
}

// Sub-kelas dari Animal
class Singa extends Darat {
    constructor(nama) {
        super(nama);
    }

    bersuara() {
        console.log(`${this.nama} mengaum.`);
    }
}

class Ikan extends Air {
    constructor(nama) {
        super(nama);
    }

    bersuara() {
        console.log(`${this.nama} mengeluarkan suara berdesir.`);
    }
}

class Katak extends Amfibi {
    constructor(nama) {
        super(nama);
    }

    bersuara() {
        console.log(`${this.nama} mengeluarkan suara "krok-krok".`);
    }
}

class Platipus extends Amfibi {
    constructor(nama) {
        super(nama);
    }

    bersuara() {
        console.log(`${this.nama} mengeluarkan suara unik.`);
    }
}

// Membuat objek
const singa = new Singa("Simba");
const ikan = new Ikan("Nemo");
const katak = new Katak("Kermit");
const platipus = new Platipus("Perry");

// Menguji objek-objek
singa.bergerak();
singa.bersuara();

ikan.berenang();
ikan.bersuara();

katak.bergerak();
katak.berenang();
katak.bersuara();

platipus.bergerak();
platipus.berenang();
platipus.bersuara();
